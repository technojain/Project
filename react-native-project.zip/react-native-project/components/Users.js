import { FlatList, StyleSheet, View } from 'react-native';
import { Button, Text } from 'react-native-elements';
import React from 'react';
import { styles } from './style';

const Users = ({ navigation, data }) => {

  const renderItem = ({ item }) => (
    <Button
      title={item.name}
      buttonStyle={{
        width: '100%',
        justifyContent: 'flex-start',
      }}
      titleStyle={{color: "#000000"}}
      containerStyle={styles.item}
      onPress={() =>
        navigation.navigate(`user${item.id}`)
      }
    />
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Users List</Text>
      <FlatList
        style={{ width: '100%' }}
        data={data}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
};

export default Users;