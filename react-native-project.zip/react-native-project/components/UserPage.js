import { FlatList, StyleSheet, View } from 'react-native';
import { Button, Text } from 'react-native-elements';
import React from 'react';
import axios from 'axios';
import { styles } from './style';

const Users = ({ navigation, id, header }) => {
  const [userInfo, setUserInfo] = React.useState();

  const fetchData = async () => {
    await axios
      .get(`https://jsonplaceholder.typicode.com/users/${id}`)
      .then((res) => setUserInfo(res.data))
      .catch((err) => alert(err));
  }

  React.useEffect(() => {
    fetchData();
  }, []);

  React.useLayoutEffect(() => {
  navigation.setOptions({
    headerBackTitle: 'Users',
    headerTitle: header,
  });
  }, [navigation]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{userInfo?.name}</Text>
      <Text style={styles.info}>Name: {userInfo?.name}</Text>
      <Text style={styles.info}>Email: {userInfo?.email}</Text>
      <Text style={styles.info}>Phone: {userInfo?.phone}</Text>
      <Text style={styles.info}>Website: {userInfo?.website}</Text>
      <Text style={styles.info}>Address: {userInfo?.address?.city}, {userInfo?.address?.street},{' '}
        {userInfo?.address?.suite}
      </Text>
    </View>
  );
};

export default Users;