import { FlatList, StyleSheet, View } from 'react-native';
import { Button, Text } from 'react-native-elements';
import React from 'react';
import axios from 'axios';
import { styles } from './style';

const StoryPage = ({ navigation, id, header }) => {
  const [storyInfo, setStoryInfo] = React.useState();

  const fetchData = async () => {
    await axios
      .get(`https://jsonplaceholder.typicode.com/posts/${id}`)
      .then((res) => setStoryInfo(res.data))
      .catch((err) => alert(err));
  }

  React.useEffect(() => {
    fetchData();
  }, []);

  React.useLayoutEffect(() => {
  navigation.setOptions({
    headerBackTitle: 'Stories',
    headerTitle: header,
  });
  }, [navigation]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{storyInfo?.title}</Text>
      <Text style={styles.info}>{storyInfo?.body}</Text>
    </View>
  );
};

export default StoryPage;