import * as React from 'react';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StatusBar } from 'expo-status-bar';
import Users from './components/Users';
import UserPage from './components/UserPage';
import Stories from './components/Stories';
import StoryPage from './components/StoryPage';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

export default function App() {
  const [users, setUsers] = React.useState();
  const [stories, setStories] = React.useState();

  const fetchData = async () => {
    await fetch('https://jsonplaceholder.typicode.com/users')
    .then(response => response.json())
    .then(data => setUsers(data))
    .catch((err) => alert(err));

    await fetch('https://jsonplaceholder.typicode.com/posts')
    .then(response => response.json())
    .then(data => setStories(data))
    .catch((err) => alert(err));
  }

  React.useEffect(() => {
    fetchData();
  }, [])

  const BottomPanel = ({ navigation }) => {
    return (
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarActiveTintColor: '#f194ff',
          tabBarInactiveTintColor: '#000000',
        })}
      >
        <Tab.Screen name='Users' options={{ headerShown: false }}>
          {(props) => <Users {...props} data={users} />}
        </Tab.Screen>
        <Tab.Screen name='Stories' options={{ headerShown: false }}>
          {(props) => <Stories {...props} data={stories} />}
        </Tab.Screen>
      </Tab.Navigator>
    );
  };

  return (
    <NavigationContainer>
      <StatusBar barStyle='dark-content' />
      <Stack.Navigator>
        <Stack.Screen
          name='BottomPanel'
          component={BottomPanel}
          options={{ headerShown: false }}
        />
        {
          users?.map((user) => {
            return (
              <Stack.Screen key={`user${user.id}`} name={`user${user.id}`}>
              {(props) => <UserPage {...props} id={user.id} header={user.name} />} 
              </Stack.Screen>
            )
          })
        }
        {
          stories?.map((story) => {
            return (
              <Stack.Screen key={`story${story.id}`} name={`story${story.id}`}>
               {(props) => <StoryPage {...props} id={story.id} header={story.title} />} 
              </Stack.Screen>
            )
          })
        }
      </Stack.Navigator>
    </NavigationContainer>
  );
}